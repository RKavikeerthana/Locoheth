import React, { useState } from 'react';
import axios from 'axios';

const MLPage = () => {
  const [trainingStatus, setTrainingStatus] = useState(null);
  const [prediction, setPrediction] = useState(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);  // Track loading state for both training and prediction

  // Function to train the LSTM model
  const handleTrainModel = async () => {
    setLoading(true);  // Set loading state to true when training starts
    try {
      const response = await axios.post('http://localhost:4000/api/lstm/train', {
        inputs: [
          [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
          [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1],
        ],
        outputs: [1, 0],
      });
      setTrainingStatus(response.data.message);  // Show training result message
    } catch (error) {
      console.error('Error training model:', error);
      setTrainingStatus('Error training model');
    } finally {
      setLoading(false);  // Set loading state to false when training is finished
    }
  };

  // Function to make a prediction with the trained model
  const handlePredict = async () => {
    setLoading(true);  // Set loading state to true when prediction starts
    try {
      // Validate input: Ensure the input has exactly 10 comma-separated numbers
      const inputArray = input.split(',').map(Number);
      if (inputArray.length !== 10 || inputArray.some(isNaN)) {
        alert('Please enter exactly 10 valid numbers, separated by commas.');
        setLoading(false);
        return;
      }

      const response = await axios.post('http://localhost:4000/api/lstm/predict', {
        input: inputArray,
      });
      setPrediction(response.data.prediction);  // Show prediction result
    } catch (error) {
      console.error('Error making prediction:', error);
      setPrediction('Error making prediction');
    } finally {
      setLoading(false);  // Set loading state to false when prediction is finished
    }
  };

  return (
    <div>
      <h1>Machine Learning Analysis</h1>

      <div className="my-4">
        {/* Train Model Button */}
        <button
          onClick={handleTrainModel}
          className="bg-primary text-white p-2 rounded"
          disabled={loading}  // Disable button while loading
        >
          {loading ? 'Training...' : 'Train Model'}
        </button>
        {trainingStatus && (
          <div className="mt-2">
            <h3>Status: {trainingStatus}</h3>
          </div>
        )}
      </div>

      <div className="my-4">
        {/* Predict Form */}
        <h2>Make a Prediction</h2>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter 10 comma-separated values"
          className="p-2 border rounded"
        />
        <button
          onClick={handlePredict}
          className="bg-secondary text-white p-2 rounded ml-2"
          disabled={loading}  // Disable button while loading
        >
          {loading ? 'Predicting...' : 'Predict'}
        </button>

        {prediction !== null && (
          <div className="mt-4">
            <h3>Prediction Result: {prediction}</h3>
          </div>
        )}
      </div>
    </div>
  );
};

export default MLPage;
