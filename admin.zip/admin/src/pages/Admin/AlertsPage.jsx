import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify'; // Add this import

const AlertsPage = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const response = await axios.get('/api/alerts'); // Replace with your actual endpoint
        const newAlerts = response.data;

        if (Array.isArray(newAlerts)) {
          setAlerts(newAlerts);
          // Notify if new alerts are found
          if (newAlerts.length > 0) {
            toast.info(`${newAlerts.length} new alerts found!`);
          }
        } else {
          console.error('Expected an array of alerts');
        }
      } catch (error) {
        console.error('Error fetching alert data:', error);
      }
    };

    fetchAlerts();
  }, []);

  return (
    <div>
      <h1>Alerts Page</h1>
      <p>This page displays alerts based on patient admission data.</p>
      {alerts.length > 0 ? (
        alerts.map((alert, index) => (
          <div key={index} className="border p-4 my-2 rounded shadow">
            <p><strong>Region:</strong> {alert.region}</p>
            <p><strong>Condition:</strong> {alert.condition}</p>
            <p><strong>Admission Count:</strong> {alert.count}</p>
            <p><strong>Alert Status:</strong> {alert.active ? 'Active' : 'Inactive'}</p>
          </div>
        ))
      ) : (
        <p>No alerts currently.</p>
      )}
    </div>
  );
};

export default AlertsPage;
