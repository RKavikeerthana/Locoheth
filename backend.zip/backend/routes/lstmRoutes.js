// routes/lstmRoutes.js

import express from 'express';
import { trainModel, predictSequence } from '../controllers/lstmController.js';

const router = express.Router();

// Route for training the LSTM model
router.post('/train', trainModel);

// Route for making predictions with the LSTM model
router.post('/predict', predictSequence);

export default router;
