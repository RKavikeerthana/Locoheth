import jwt from "jsonwebtoken";

// User authentication middleware
const authUser = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization; // Use `authorization` header for bearer tokens
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return res.status(401).json({
                success: false,
                message: "Unauthorized: No token provided.",
            });
        }

        const token = authHeader.split(" ")[1]; // Extract the token after "Bearer "
        const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

        // Attach user info to request for downstream access
        req.user = { id: decodedToken.id };
        next();
    } catch (error) {
        console.error("Token verification failed:", error);
        res.status(403).json({
            success: false,
            message: "Access denied. Invalid or expired token.",
        });
    }
};

export default authUser;
